// const request = require("request");
const cheerio = require("cheerio");
const axios = require('axios')
const fs = require('fs')

const siteUrl = "https://en.wikipedia.org/wiki/List_of_ISO_3166_country_codes"

const Request = async (url) => {
    let {data} = await axios.get(url)
    return data
}

async function main(url) {
    // console.log(url);
    // // const result = await request.get(url);
    // const $ = cheerio.load(result);
    // const scrapedData = [];
    // const tableHeaders = [];
    try {
        return Request(url).then(data => {
            const $ = cheerio.load(data, null, false);
            const scrapedData = [];
            $("table.wikitable>tbody>tr").each((index, element) => {
                const tr = $(element);
                const children = tr.children();
                const row = {
                    "name": children.eq(0).text().trim(),
                    "code": children.eq(3).text().trim(),
                    "flag": "https:" + children.eq(0).find('img').attr('src'),
                }
                scrapedData.push(row)
            })
            scrapedData.splice(0, 2);
            fs.writeFile("countries.json", JSON.stringify(scrapedData), (err) => {
                if (err) throw new Error('ошибка записи в файл: ' + err);
            });

        })
        console.log("Успешно!")
    } catch (e) {
        console.log(e)
        console.log("Произошла ошибка")
    }


    // $("body > div > div > div > div >  table > tbody > tr").each((index, element) => {


    // $("table.wikitable > tbody > tr").each((index, element) => {
    //     if (index === 1) {
    //         const ths = $(element).find("th");
    //         $(ths).each((i, element) => {
    //             tableHeaders.push(
    //                 $(element)
    //                     .text()
    //                     .toLowerCase()
    //             );
    //         });
    //         return true;
    //     }
    //     const tds = $(element).find("td");
    //     const tableRow = {};
    //     $(tds).each((i, element) => {
    //         tableRow[tableHeaders[i]] = $(element).text();
    //     });
    //     scrapedData.push(tableRow);
    // });
    // console.log(scrapedData);

}

main(siteUrl);