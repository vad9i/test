const ApiError = require('../error/AppError');
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const User = require('../models/models')
const {DataTypes} = require('sequelize')
const { validationResult } = require('express-validator')


const generateJwt = (id, email) => {
    return jwt.sign(
        {id, email},
        process.env.SECRET_KEY,
        {expiresIn: '24h'}
    )
}
/**
 * @swagger
 * /users/register:
 *   get:
 *   description: Ошибка регистрации
 *   responses:
 *       '400':
 *           description: Не авторизован
 * /users/register:
 *  get:
 *   description: Ошибка регистрации
 *   responses:
 *       '400':
 *           description: Некорректный email или password
 *
 *  /users/register:
 *  get:
 *   description: Ошибка регистрации
 *   responses:
 *   {
 *      "email": "123ya.ru",
 *      "password": "123"
 *   }
 *       '400':
 *           description: Пользователь с таким email уже существует
 *
 *   /users/register:
 *  get:
 *   description: Регистрация успешно
 *   responses:
 *   {
 *      "email": "123ya.ru",
 *      "password": "123"
 *   }
 *       '200':
 *           description: Регистрация успешно
 *  */


class UserController {
    async registration(req, res, next) {
        const errors = validationResult(req)
        if(!errors.isEmpty()) {
            return  next(ApiError.badRequest('Ошибка при регистрации', errors))
        }
        const {email, password} = req.body
        if (!email || !password) {
            return next(ApiError.badRequest('Некорректный email или password'))
        }
        const candidate = await User.findOne({where: {email}})
        if (candidate) {
            return next(ApiError.badRequest('Пользователь с таким email уже существует'))
        }
        const hashPassword = await bcrypt.hash(password, 5)
        const user = await User.create({email, password: hashPassword})
        return res.json({message: "Регистрация успешно"})
    }


    /**
     * @swagger
     * /users/login:
     *   get:
     *   description: Ошибка авторизации
     *   responses:
     *       '400':
     *           description: Login error
     * /users/login:
     *  get:
     *   description: Ошибка авторизации
     *   responses:
     *       '400':
     *           description: Указан неверный пароль
     *
     *  /users/login:
     *  get:
     *   description: Ошибка авторизации
     *   responses:
     *       '400':
     *           description: Пользователь не найден
     *
     *  */

    async login(req, res, next) {
        try {
            const {email, password} = req.body
            const user = await User.findOne({where: {email}})
            if (!user) {
                return next(ApiError.badRequest('Пользователь не найден'))
            }
            let comparePassword = bcrypt.compareSync(password, user.password)
            if (!comparePassword) {
                return next(ApiError.badRequest('Указан неверный пароль'))
            }
            const token = generateJwt(user.id, user.email)
            return res.json({token})
        } catch (e) {
            // console.log(e)
            return next(ApiError.badRequest('Login error'))
        }
    }

    async check(req, res, next) {
        const email = req.user.email
        return res.json({email})
    }
}

module.exports = new UserController()
