require('dotenv').config()
const express = require('express')
const sequelize = require('./db')
const models = require('./models/models')
const cors = require('cors')
const router = require('./routes/userRouter')
const errorHandler = require('./middleware/ErrorHandlingMiddleware')
const swaggerJsDoc = require('swagger-jsdoc')
const swaggerUi = require('swagger-ui-express')

const PORT = process.env.PORT || 5000

const swaggerOptions = {
    swaggerDefinition: {
        info: {
            title: "User API",
            description: "User API Information",
            contact: {
                name: "Amazing developer"
            },
            servers: ["http://localhost:5000"]
        }
    },
    // ['./routes/*.js']
    apis: ["index.js"]
};

module.exports = swaggerOptions;
const swaggerDocs = swaggerJsDoc(swaggerOptions);


const app = express()
app.use(cors())
app.use(express.json())
app.use('/', router)

// Router для swagger
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocs));
/**
 * @swagger
 * /customers:
 *   get:
 *   description: Use to request all customers
 *   responses:
 *       '200':
 *           description: A successful response
 *
 *  */

// Обработка ошибок, последний Middleware
app.use(errorHandler)

const start = async () => {
    try {
        await sequelize.authenticate()
        await sequelize.sync()
        app.listen(PORT, () => console.log(`Server started on port ${PORT}`))
    } catch (e) {
        console.log(e)
    }
}


start()
