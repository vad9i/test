const jwt = require('jsonwebtoken')


/**
 * @swagger
 * /users:
 *   get:
 *   description: Ошибка авторизации
 *   responses:
 *       '401':
 *           description: Не авторизован
 *
 *  */
module.exports = function (req, res, next) {
    if (req.method === "OPTIONS") {
        next()
    }
    try {
        const token = req.headers.authorization.split(' ')[1] // Bearer asfasnfkajsfnjk
        if (!token) {
            return res.status(401).json({message: "Не авторизован"})
        }
        const decoded = jwt.verify(token, process.env.SECRET_KEY)
        req.user = decoded
        next()
    } catch (e) {
        // console.log(e)
        res.status(401).json({message: "Не авторизован"})
    }
};
